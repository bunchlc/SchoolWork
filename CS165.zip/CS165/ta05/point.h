#ifndef POINT_H
#define POINT_H

class Point
{
private:
   int x;
   int y;

public:

   int getX(return x);
   int getY(return y);

   void setX(const int x);
   void setY(const int y);

   void display() const;

};

#endif
